#1) Introduction
#In this project, we'll be working with a csv file containing index prices. Each row in the file contains a daily record of the price of the S&P500 Index from 1950 to 2015. The dataset is stored in the file "sphist.csv".

#The columns of the dataset are:

#Date -- The date of the record.
#Open -- The opening price of the day (when trading starts).
#High -- The highest trade price during the day.
#Low -- The lowest trade price during the day.
#Close -- The closing price for the day (when trading is finished).
#Volume -- The number of shares traded.
#Adj Close -- The daily closing price, adjusted retroactively to include any corporate actions. Read more here.

#1.1) Project goal
#We'll be using this dataset to develop a predictive model. We'll train the model with data from 1950-2012 and try to make predictions from 2013-2015.


#2) Data preparation

# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from matplotlib import style


# Read the datafile, parse dates on "Date"
data = pd.read_csv("sphist.csv", parse_dates=["Date"])

# Sort by "Date" column
data.sort_values("Date", ignore_index=True, inplace=True)

# Display basic info
display(data.info())
display(data.head())


# Initially set the columns to zero
data["prev5_avg"] = 0
data["prev5_std"] = 0
data["prev30_avg"] = 0
data["prev30_std"] = 0
data["prev365_avg"] = 0
data["prev365_std"] = 0

# Iterate over each row to compute the columns using previous 5, 30 and 365 rows (days)
for index, row in data.iterrows():
    # Subset the previous 5 rows, compute the average and standard deviation of "Close" column, and set the columns' values
    past5 = data.iloc[index-5:index]
    past5_avg = past5["Close"].mean()
    past5_std = past5["Close"].std()
    data.loc[index, "prev5_avg"] = past5_avg
    data.loc[index, "prev5_std"] = past5_std
    # Subset the previous 30 rows, compute the average and standard deviation of "Close" column, and set the columns' values
    past30 = data.iloc[index-30:index]
    past30_avg = past30["Close"].mean()
    past30_std = past30["Close"].std()
    data.loc[index, "prev30_avg"] = past30_avg
    data.loc[index, "prev30_std"] = past30_std
    # Subset the previous 365 rows, compute the average and standard deviation of "Close" column, and set the columns' values
    past365 = data.iloc[index-365:index]
    past365_avg = past365["Close"].mean()
    past365_std = past365["Close"].std()
    data.loc[index, "prev365_avg"] = past365_avg
    data.loc[index, "prev365_std"] = past365_std
    
# Display info
display(data.head(10))

#Since we're computing indicators that use historical data, there are some rows where there isn't enough historical data to generate them. Some of the indicators use 365 days of historical data and the dataset starts on 1950-01-03. Thus, any rows that fall before 1951-01-03 don't have enough historical data to compute all the indicators. We'll need to remove these rows before we split the data.

#3) Create a model to predict new data
#We'll start by creating a model that only uses the average value of the previous 5 days and see how it behaves.
# Linear Regression model with only one possible predictor
lr = LinearRegression()
lr.fit(train[["prev5_avg"]], train["Close"])
predictions = lr.predict(test[["prev5_avg"]])
rmse = mean_squared_error(predictions, test["Close"]) ** 1/2

# Plot the model vs actual values
style.use("fivethirtyeight")
plt.figure(figsize=(15,10))
plt.plot(test["Date"], test["Close"])
plt.plot(test["Date"], predictions)
plt.legend(["Actual", "Predicted"])
plt.show()

# Display RMSE value
print("RMSE value:", round(rmse,1))

#Finally, we'll compare our previous model with a model that uses all 6 possible predictor variables that we created, to compare their RMSE values (a better model should decrease RMSE values).


# Linear Regression model with the 6 possible predictors
lr = LinearRegression()
lr.fit(train[["prev5_avg", "prev5_std", "prev30_avg", "prev30_std", "prev365_avg", "prev365_std"]], train["Close"])
predictions = lr.predict(test[["prev5_avg", "prev5_std", "prev30_avg", "prev30_std", "prev365_avg", "prev365_std"]])
rmse = mean_squared_error(predictions, test["Close"]) ** 1/2

# Plot the model vs actual values
style.use("fivethirtyeight")
plt.figure(figsize=(15,10))
plt.plot(test["Date"], test["Close"])
plt.plot(test["Date"], predictions)
plt.legend(["Actual", "Predicted"])
plt.show()

# Display RMSE value
print("RMSE value:", round(rmse,1))


# 4) Conclusion
#Both models did well on predicting the data. However, a more complicated model using 6 predictor variables barely decreased RMSE values. Therefore, for the purpose of this project, we could keep the first model, using only the average value of the closing prices of the previous 5 days.